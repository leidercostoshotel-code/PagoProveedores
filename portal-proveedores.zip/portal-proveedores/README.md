# Portal de consulta de pagos a proveedores

Portal web en Firebase donde cada proveedor consulta sus facturas pagadas, fecha de abono,
banco y desglose de descuentos (retención, detracción, notas de crédito).

## Puesta en marcha
1. `npm install`
2. Crea un proyecto en Firebase, habilita **Authentication (Email/Password)** y **Firestore**.
3. Copia `.firebaserc.example` a `.firebaserc` y pon tu `projectId`.
4. Edita `public/index.html`: reemplaza `apiKey`, `authDomain` y `projectId`.
5. Descarga la clave de servicio (Configuración → Cuentas de servicio) y guárdala como `serviceAccount.json` en la raíz (está en `.gitignore`).
6. `npm run deploy`

## Cargar un lote de pagos
```
npm run cargar -- PROV_20261024.txt descuentos.csv
```
El TXT es el archivo de Pago a Proveedores de Telecrédito BCP; el CSV sale de SAP B1 con el formato de `ejemplos/descuentos.csv`.
Ajusta primero las posiciones de columna en `scripts/cargar-pagos-bcp.js`.

## Alta de proveedores
En Firebase Auth crea el usuario `<RUC>@proveedores.hotel` con una clave inicial y entrégala al proveedor.
