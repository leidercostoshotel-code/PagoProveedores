# Portal de Proveedores — contexto para Claude Code

Sistema de consulta de pagos para proveedores de un hotel en Lima. Elimina las consultas
manuales a Contabilidad: el proveedor entra con su RUC y clave y ve sus facturas pagadas.

## Estructura
- `public/index.html` — portal web (HTML + JS vanilla, Firebase SDK v10 modular: Auth + Firestore). Se despliega en Firebase Hosting.
- `scripts/cargar-pagos-bcp.js` — carga en Firestore el TXT de Telecrédito BCP (Pago a Proveedores) cruzado con un CSV de descuentos exportado de SAP Business One.
- `firestore.rules` — cada proveedor solo lee documentos de `pagos` cuyo `ruc` coincide con su usuario.
- `firestore.indexes.json` — índice compuesto `ruc ASC + fechaPago DESC`.
- `ejemplos/descuentos.csv` — formato del CSV de SAP (`factura;ruc;bruto;retencion;detraccion;notaCredito`).

## Modelo de datos (colección `pagos`, ID = `RUC_FACTURA_AAAAMMDD`)
ruc, razonSocial, factura, fechaPago (YYYY-MM-DD), banco, cuentaAbono, bruto, retencion,
detraccion, notaCredito, neto, lote, cargadoEn.

## Autenticación
Email/password en Firebase Auth. El usuario es sintético: `<RUC>@proveedores.hotel`.
Contabilidad crea el usuario y entrega la clave inicial.

## Pendientes conocidos
- Ajustar posiciones de ancho fijo en `scripts/cargar-pagos-bcp.js` (bloque CABECERA/DETALLE) con un TXT real.
- Forzar cambio de clave en el primer ingreso (`updatePassword`).
- Reemplazar `apiKey`, `authDomain`, `projectId` en `public/index.html`.
- Posible soporte futuro para TXT de Interbank y BBVA.

## Convenciones
- Código y comentarios en español. Sin frameworks en el frontend.
- No subir `serviceAccount.json`, TXT ni CSV reales al repositorio.
